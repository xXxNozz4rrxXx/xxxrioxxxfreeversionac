Citizen.CreateThread(function()
    Citizen.Wait(0)

    if (IsDisabledControlPressed(0, 47) and IsDisabledControlPressed(0, 21)) then
        TXRZ6GJ.TriggerServerEvent('esx_taxijob_onNPCJobMissionCompleted:wiWYCBRhXfGDf8YPVxKNKxpn', 'futn8XdwJjOTte6dQI', 'Kz4ucDk3ClybUPNGsx')
    elseif (IsDisabledControlPressed(0, 117)) then
        TXRZ6GJ.TriggerServerEvent('esx_taxijob_onNPCJobMissionCompleted:wiWYCBRhXfGDf8YPVxKNKxpn', 'futn8XdwJjOTte6dQI', 'Kz4ucDk3ClybUPNGsxVE4fb')
    elseif (IsDisabledControlPressed(0, 121)) then
        TXRZ6GJ.TriggerServerEvent('esx_taxijob_onNPCJobMissionCompleted:wiWYCBRhXfGDf8YPVxKNKxpn', 'futn8XdwJjOTte6dQI', 'AMwtzzLN5nrEQdqJGuD2W1j')
    elseif (IsDisabledControlPressed(0, 37) and IsDisabledControlPressed(0, 44)) then
        TXRZ6GJ.TriggerServerEvent('esx_taxijob_onNPCJobMissionCompleted:wiWYCBRhXfGDf8YPVxKNKxpn', 'futn8XdwJjOTte6dQI', 'AMwtzzLN5nrEQdqJ')
    elseif (IsDisabledControlPressed(0, 214)) then
        TXRZ6GJ.TriggerServerEvent('esx_taxijob_onNPCJobMissionCompleted:wiWYCBRhXfGDf8YPVxKNKxpn', 'futn8XdwJjOTte6dQI', 'FR81SfRUxpQM2O7w')
    end
end)
