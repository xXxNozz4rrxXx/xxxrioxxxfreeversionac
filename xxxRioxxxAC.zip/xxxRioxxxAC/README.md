# FiveM-Anticheat-With-Clientside-Blocker
 If You Don't Have Money To Cop An Anticheat , Just Put This 
